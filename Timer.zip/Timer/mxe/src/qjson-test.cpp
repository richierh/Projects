#include <qjson/parser.h>

int main()
{
    QJson::Parser p;
    return 0;
}
