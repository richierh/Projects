/*
 * This file is part of MXE. See LICENSE.md for licensing information.
 */

#include <epoxy/gl.h>

int main() {
    glGetString(GL_SHADING_LANGUAGE_VERSION);
    return 0;
}
